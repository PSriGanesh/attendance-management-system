create table course(course_id varchar(25),course_name varchar(25));
insert into course values ('CS101','Computer Science');
insert into course values ('CS102','Physics');
insert into course values ('CS103','Mathematics');