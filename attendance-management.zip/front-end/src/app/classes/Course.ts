export interface Course {
    courseId: string;
    courseName: string
  }