export interface Student {
    id: number;
    name: string;
    session: string;
    semester: string;
    subject_Id: string;
    course: string;
    status: string;
    email: string;
    contact_Number: number;
  }