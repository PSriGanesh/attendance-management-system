export interface User {
    name: string;
    email: string;
    password: string;
    userType: string;
    contact_number: number;


  //   private String name;
	// private String email;
	// private String password;
	// private String userType;
	// private Long contact_Number;
  }